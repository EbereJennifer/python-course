"""
Eine geeignete Datenstruktur (mehrere ausprobieren) mit vier
Begrüßungsformeln (wie "Hallo", "Guten Tag", ...) erstellen,
zufällig eine Begrüßung auswählen.
"""

import random

list_formeln = ["Guten Morgen", "Hi", "Hallo", "Grüß Gott", "Buenos dias"]
set_formeln = {"Guten Morgen", "Hi", "Hallo", "Grüß Gott", "Buenos dias"}
tupel_formeln = ("Guten Morgen", "Hi", "Hallo", "Grüß Gott", "Buenos dias")

# gruß = random.choice(list_formeln) ok
#gruß = random.choice(set_formeln) funktioniert nicht
gruß = random.choice(tupel_formeln) # ok
print(gruß)


