"""
Funktion lottozahlen() berechnet 6 Lottozahlen im Bereich 1-49.
Geeignete Funktion aus random soll verwendet werden.
"""

import random

def lottozahlen():
    zahlen = random.sample(range(1, 50), k=6)
    return sorted(zahlen)


print(lottozahlen())
