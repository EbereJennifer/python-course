import math

"""
Eine Wertetabelle aller Sinus- und Cosinuswerte für 0 - 180 Grad 
(Abstand 10 Grad) berechnen und anzeigen.
"""

# Parameter ist selbst eine Funktion
# trig_tabelle ist eine Funktion zweiter Ordnung
def trig_tabelle(trig_fun):
    for grad in range(0, 190, 10):
        rad = math.radians(grad)
        y = trig_fun(rad)
        print(f"{trig_fun.__name__} an der Stelle {grad:3} Grad: {y:8.6f}")


trig_tabelle(math.sin)
print("*" * 40)
trig_tabelle(math.cos)
