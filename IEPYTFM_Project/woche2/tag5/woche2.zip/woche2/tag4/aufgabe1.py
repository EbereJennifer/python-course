"""
Evt. recherchieren: Satz des Pythagoras, Anwendung auf die Seiten eines rechtwinkligen Dreiecks.
Funktion definieren:
Man soll die beiden kürzeren Seitenlängen als Kommazahlen eingeben können,
die Länge der längsten Seite (Hypotenuse) soll berechnet werden.
"""

import math

def compute_hypotenuse(kathete1, kathete2):
    quadrat1 = math.pow(kathete1, 2)
    quadrat2 = math.pow(kathete2, 2)
    summe = quadrat1 + quadrat2
    wurzel = math.sqrt(summe)
    return wurzel


hypo = compute_hypotenuse(3, 4)
print(hypo)

print(__file__, __name__)
print()

print("*" * 40)

string1 = input("Erste Seitenlänge: ")
kathete1 = float(string1)

string2 = input("Zeite Seitenlänge: ")
kathete2 = float(string2)

hypotenuse = compute_hypotenuse(kathete1, kathete2)
print(f"Länge der Hypotenuse: {hypotenuse:.4f}")










