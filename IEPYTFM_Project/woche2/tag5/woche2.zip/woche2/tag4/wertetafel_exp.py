import math

def wertetafel(start, end, anzahl):
    abstand = (end - start) / (anzahl - 1)
    for i in range(anzahl):
        x = start + i * abstand
        y =  math.exp(x)
        # e wissenschaftliche Darstellung von Kommazahlen
        print(f"x = {x:8.4f}\t  exp(x) = {y:18.8e}")


wertetafel(10, 100, 20)

